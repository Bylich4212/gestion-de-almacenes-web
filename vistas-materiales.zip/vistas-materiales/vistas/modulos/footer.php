 <footer class="main-footer">
    <strong>Copyright &copy; 2020 <a href="http://123456789.io" target="_blank">MeylinStore</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.0-rc.2
    </div>
  </footer>