<?php

class ControladorPlantilla{

	static public function plantilla(){

		include "vistas/plantilla.php";
	}
}